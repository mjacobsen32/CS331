to run it needs to be in python3

> python3 analysis.py
